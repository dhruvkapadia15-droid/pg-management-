# PG Management System (Laravel)

Stack: Laravel + PHP (Eloquent, Blade), HTML, CSS, JavaScript, XML (house rules in, tenant register out).

## Setup (needs PHP 8.2+ and Composer)
1. Create a fresh Laravel app:   composer create-project laravel/laravel pg-app
2. Copy the contents of this folder INTO pg-app and allow overwrite
   (routes/, app/, database/, resources/, public/).
3. Inside pg-app run:
     php artisan migrate     (SQLite by default; answer yes if asked to create the DB file)
     php artisan serve
4. Open http://127.0.0.1:8000

Add rooms first, then tenants, then payments.
XML: edit public/xml/rules.xml. Download the tenant register at /export/tenants.xml
